<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">@yield('content')</div>
	</div>
</div>